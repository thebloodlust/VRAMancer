╔═══════════════════════════════════════════════════════════════════╗
║                   VRAMancer pour macOS                            ║
║              Orchestrateur IA Multi-GPU                           ║
╚═══════════════════════════════════════════════════════════════════╝

📦 INSTALLATION
───────────────

1. Glissez l'icône VRAMancer.app dans le dossier Applications
2. Lancez VRAMancer depuis Applications ou Launchpad
3. Au premier lancement, l'application installera les dépendances Python

⚙️ PRÉREQUIS
─────────────

• Python 3.9 ou supérieur (installé par défaut sur macOS 10.15+)
• Si Python n'est pas installé : https://www.python.org/downloads/macos/

🚀 PREMIER LANCEMENT
────────────────────

• L'installation des dépendances prend 2-5 minutes
• L'API démarre automatiquement sur http://localhost:5030
• Le System Tray apparaît dans la barre de menu (si PyQt5 installé)
• Sinon, le dashboard web s'ouvre dans votre navigateur

🎮 INTERFACES DISPONIBLES
──────────────────────────

1. System Tray (barre de menu) - Recommandé
2. Dashboard Web - http://localhost:5030
3. Dashboard Qt - Interface graphique native
4. Dashboard Mobile - Responsive design

Pour installer PyQt5 et activer le System Tray :
  python3 -m pip install PyQt5

📚 DOCUMENTATION
────────────────

• README.md : Documentation complète (dans VRAMancer.app/Contents/MacOS/)
• MANUEL_FR.md : Guide en français
• MANUAL_EN.md : English manual
• http://localhost:5030/docs : Documentation API

🛠️ LANCEMENT MANUEL
────────────────────

Terminal :
  cd /Applications/VRAMancer.app/Contents/MacOS
  source .venv/bin/activate
  python3 api_simple.py &
  python3 systray_vramancer.py

Ou :
  ./vrm_start.sh

🔍 DÉPANNAGE
─────────────

• Logs : ~/.vramancer/logs/
• API ne démarre pas : vérifier le port 5030 (lsof -i :5030)
• PyQt5 non trouvé : pip3 install PyQt5
• Python non trouvé : installer depuis python.org

📧 SUPPORT
──────────

• GitHub : https://github.com/thebloodlust/VRAMancer
• Issues : https://github.com/thebloodlust/VRAMancer/issues

Version 1.0.0 - 2025
Licence MIT
