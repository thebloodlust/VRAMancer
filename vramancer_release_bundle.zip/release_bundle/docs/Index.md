# Accueil
Bienvenue sur la documentation de **VR‑C Inference**.  
Ce dépôt fournit un petit framework pour exécuter des modèles de langage (GPT‑2‑style) sur plusieurs GPU (CUDA, ROCm / HIP, M‑series) tout en gardant un contrôle sur la répartition des blocs.
