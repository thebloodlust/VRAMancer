# Interface mobile/tablette

## Module : `mobile/dashboard_mobile.py`
- Dashboard Flask responsive pour contrôle et monitoring mobile
- Vue simple, accès sécurisé possible

### Lancer le dashboard mobile
```bash
python3 mobile/dashboard_mobile.py
```

Ouvrir sur mobile/tablette : http://<ip>:5003/

---
À enrichir selon les besoins (auth, monitoring live, actions distantes, etc.).
