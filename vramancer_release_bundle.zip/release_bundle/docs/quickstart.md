# Quickstart

```bash
git clone https://github.com/your‑org/vrc_inference.git
cd vrc_inference
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python examples/quickstart.py
