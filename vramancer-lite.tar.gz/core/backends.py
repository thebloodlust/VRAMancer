# ------------------- Sélection dynamique du backend -------------------
def select_backend(backend_name: str = "auto"):
    """
    Sélectionne dynamiquement le backend LLM selon le nom ou l’environnement.
    - backend_name : "huggingface", "vllm", "ollama", ou "auto"
    """
    backend_name = (backend_name or "auto").lower()
    if backend_name == "huggingface":
        return HuggingFaceBackend()
    if backend_name == "vllm":
        try:
            import vllm  # noqa: F401
            return vLLMBackend()
        except ImportError:
            raise RuntimeError("vLLM n'est pas installé.")
    if backend_name == "ollama":
        try:
            import ollama  # noqa: F401
            return OllamaBackend()
        except ImportError:
            raise RuntimeError("Ollama n'est pas installé.")
    # Mode auto : priorité vLLM > Ollama > HuggingFace
    try:
        import vllm  # noqa: F401
        return vLLMBackend()
    except ImportError:
        pass
    try:
        import ollama  # noqa: F401
        return OllamaBackend()
    except ImportError:
        pass
    return HuggingFaceBackend()
# core/backends.py
"""
Abstraction unifiée pour les backends LLM (HuggingFace, vLLM, Ollama, etc.)
"""
from abc import ABC, abstractmethod
from typing import Any, List

class BaseLLMBackend(ABC):
    """
    Interface générique pour tous les backends LLM.
    """
    @abstractmethod
    def load_model(self, model_name: str, **kwargs) -> Any:
        pass

    @abstractmethod
    def split_model(self, num_gpus: int, vram_per_gpu: List[int] = None) -> List[Any]:
        """
        Découpe le modèle en blocs selon le nombre de GPUs et la VRAM disponible.
        """
        pass

    @abstractmethod
    def infer(self, inputs: Any) -> Any:
        pass

# ------------------- HuggingFace Backend -------------------
class HuggingFaceBackend(BaseLLMBackend):
    def __init__(self):
        self.model = None
        self.blocks = None

    def load_model(self, model_name: str, **kwargs):
        from transformers import AutoModelForCausalLM
        self.model = AutoModelForCausalLM.from_pretrained(model_name, **kwargs)
        return self.model

    def split_model(self, num_gpus: int, vram_per_gpu: List[int] = None):
        # TODO: utiliser split_model_into_blocks adapté à la VRAM réelle
        from core.model_splitter import split_model_into_blocks
        self.blocks = split_model_into_blocks(self.model, num_gpus, vram_per_gpu)
        return self.blocks

    def infer(self, inputs: Any):
        # Simple forward sur tous les blocs (à adapter pour pipeline multi-GPU)
        x = inputs
        for block in self.blocks:
            x = block(x)
        return x

# ------------------- vLLM Backend (squelette) -------------------
class vLLMBackend(BaseLLMBackend):
    def __init__(self):
        self.model = None

    def load_model(self, model_name: str, **kwargs):
        # TODO: intégrer l’API vLLM (ex: vllm.LLM)
        raise NotImplementedError("vLLMBackend: load_model non implémenté")

    def split_model(self, num_gpus: int, vram_per_gpu: List[int] = None):
        # TODO: découpage vLLM natif
        raise NotImplementedError("vLLMBackend: split_model non implémenté")

    def infer(self, inputs: Any):
        # TODO: appel vLLM natif
        raise NotImplementedError("vLLMBackend: infer non implémenté")

# ------------------- Ollama Backend (squelette) -------------------
class OllamaBackend(BaseLLMBackend):
    def __init__(self):
        self.model = None

    def load_model(self, model_name: str, **kwargs):
        # TODO: intégrer l’API Ollama (ex: via REST ou Python SDK)
        raise NotImplementedError("OllamaBackend: load_model non implémenté")

    def split_model(self, num_gpus: int, vram_per_gpu: List[int] = None):
        # TODO: découpage Ollama natif (si possible)
        raise NotImplementedError("OllamaBackend: split_model non implémenté")

    def infer(self, inputs: Any):
        # TODO: appel Ollama natif
        raise NotImplementedError("OllamaBackend: infer non implémenté")
